# فرصة — الواجهات الرئيسية

واجهة عربية متجاوبة باتجاه RTL مبنية باستخدام React وTypeScript وVite وTailwind CSS.

## التشغيل المحلي

```bash
npm install
cp .env.example .env
npm run dev
```

افتح عنوان Vite الظاهر في الطرفية. يعمل التنقل عبر `HashRouter`، لذلك لا يحتاج إعداد إعادة توجيه للمسارات عند النشر داخل مجلد فرعي أو عند تضمينه لاحقاً في Capacitor.

## البناء والمعاينة

```bash
npm run build
npm run preview
```

ملفات الإنتاج تُنشأ داخل `dist/`، مع `base: './'` لدعم المسارات النسبية.

## ربط الـ API

أضف عنوان الجذر إلى `.env`:

```env
VITE_API_BASE_URL=https://your-api.example
```

تتوقع الواجهة:

- `GET {VITE_API_BASE_URL}/?resource=services` مع استجابة تتضمن `data` كمصفوفة خدمات.
- `POST {VITE_API_BASE_URL}/?resource=ads` لإرسال إعلان JSON بالحقول `title` و`description` و`category`.

عند غياب عنوان API، تُعرض الخدمات المحلية المحددة في الواجهة، ويُحفظ إرسال الإعلان كمسودة تجريبية فقط.

## الصفحات والوظائف

الرئيسية وبطاقات الخدمات، البحث والفلترة، الرسائل، الإعلانات وإضافة إعلان، الحساب، والإعدادات (المظهر الفاتح/الداكن/حسب النظام، النمط، اللغة، الإشعارات، الخصوصية ومسح الذاكرة المؤقتة). تفضيلات الواجهة محفوظة في `localStorage`.


## تجهيز Android عبر Capacitor

تم إعداد `capacitor.config.json` بمعرّف التطبيق `com.abdulrazzaq.forsah` والاسم `فرصة` ومجلد الويب `dist`. غيّر `appId` إلى معرّف reverse-domain تملكه قبل النشر.

```bash
npm install
npm run build
npx cap add android       # مرة واحدة فقط، وتم إنشاء android/ لهذا المشروع
npx cap sync android      # أعدها بعد كل تعديل في واجهة الويب
npx cap open android      # فتح المشروع في Android Studio
```

يمكن تنفيذ البناء والمزامنة معًا باستخدام `npm run cap:sync`. لضغط ملفات الويب فقط:

```bash
cd dist
zip -r ../forsah-dist.zip .
```

لبناء APK تجريبي موقّع تلقائيًا بمفتاح Debug، من جذر المشروع:

```bash
cd android
./gradlew assembleDebug
```

على Windows استخدم `gradlew.bat assembleDebug`. يوجد الملف عادةً في `android/app/build/outputs/apk/debug/app-debug.apk`.

لإصدار Release قابل للتوزيع، افتح Android Studio واختر **Build > Generate Signed Bundle / APK > APK**، ثم أنشئ أو اختر keystore خاصًا بك. لا تشارك keystore أو كلمات مروره. تشغيل `./gradlew assembleRelease` وحده لا يضمن APK موقّعًا؛ إعداد التوقيع مطلوب للنشر. يتطلب بناء Android تثبيت Android Studio وAndroid SDK وJDK المناسبين للمشروع.

## لوحة الإدارة وPHP/SQLite

تتضمن النسخة لوحة محمية داخل `/#/admin` وواجهة API/قاعدة بيانات SQLite في [backend/README.md](backend/README.md). ابدأ خادم PHP وأنشئ أول حساب مدير فائق باتباع الدليل؛ لا توجد بيانات دخول افتراضية.
