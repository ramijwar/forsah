import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  base: './',
  plugins: [react()],
  preview: {
    allowedHosts: ['4173-il12wlcppo9v6lyqpebn0-5d05fccf.us2.manus.computer'],
  },
});
